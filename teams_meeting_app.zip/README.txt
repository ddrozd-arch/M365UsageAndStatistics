Teams Meeting App (Power Apps + Power Automate)

1. Create SharePoint list 'Meetings' with fields:
   - Title (Single line)
   - StartTime (DateTime)
   - EndTime (DateTime)
   - Attendees (Multiple line)
   - Description (Multiple line)
   - Status (Choice: Pending, Created, Failed)
   - TeamsLink (Hyperlink)

2. Create Power App (Canvas) and copy formulas from files.

3. Create Power Automate Flow using flow_definition.txt
